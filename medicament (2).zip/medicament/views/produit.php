
<?php
session_start();
include "../core/produitC.php";

;
include "../core/panierC.php";
include "../core/panier_ligneC.php";
include "../entities/panier_ligne.php";


$produitC= new produitC();

$panier_ligneC = new panier_ligneC();
$produits = $panier_ligneC->get_produit($_SESSION['id']);

$panierC = new panierC();

$panierresult = $panierC->afficherPanieridc($_SESSION['id']);
foreach ($panierresult as $row10) {
    $nbroduitp = $row10["nbproduit"];
    $totalep = $row10["totale"];
}

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fresca Bootstrap 4 Theme Full Screen</title>
    <meta name="description" content="Fresca is a free, open source Bootstrap 4 theme" />
    <meta name="generator" content="Themestr.app">
    <link rel="icon" href="http://themes.guide/favicon.ico" type="image/x-icon" />
    <link rel="shortcut icon" href="http://themes.guide/favicon.ico" type="image/x-icon" />
    <meta property="og:image" name="twitter:image" content="http://bootstrap.themes.guide/assets/ss_fresca.png">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:site" content="@ThemesGuide">
    <meta name="twitter:creator" content="@ThemesGuide">
    <meta name="twitter:title" content="Open-source Bootstrap 4 Themes">
    <meta name="twitter:description" content="Download Fresca - free, open source Bootstrap 4 theme by Themes.guide">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/3.0.0/css/ionicons.css" rel="stylesheet">
    <link href="./theme.css" rel="stylesheet">
    <link href="./template.css" rel="stylesheet">
    <link rel="stylesheet" href="myProjects/webProject/icofont/css/icofont.min.css">
</head>

<body data-spy="scroll" data-target="#navbar1" data-offset="60">
<nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-primary" id="navbar1">
    <div class="container">
        <a class="navbar-brand mr-1 mb-1 mt-0" href="../">Bootstrap 4</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsingNavbar">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="navbar-collapse collapse justify-content-center" id="collapsingNavbar">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a class="nav-link" href="produit.php">Produit</a>
                </li>
            </ul>
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <?php
                        if (isset($_SESSION['id']) && isset($_SESSION['username'] ))
                        { ?>
                            <span style="display: inline-block;"><a class="nav-link" href="Logout.php">Logout (<?php echo $_SESSION['username']; ?>)</a>
                            <a href="cart.php" data-toggle="modal" data-target="#exampleModalCenter"> <i class="icofont-dart icofont-1x" style="color: red;" >cart</i> </a>  </span>
                       <?php }
                        else {
                    ?>
                            <a class="nav-link" href="Login.php">Login</a>
                    <?php
                    }
                    ?>
                </li>
            </ul>
        </div>
    </div>
</nav>
<main>
    <?php
        $listproduits=$produitC->afficherproduits();
    ?>
    <section class="container">
        <div class="row vh-100">
            <div class="col-12 my-auto">
                <p class="display-1 text-truncate">Produit</p>

                <div class="row text-center">
                    <?php
                    foreach ($listproduits as $row){
                    ?>
                    <div class="col-lg-4 mb-4">
                        <div class="card h-100">
                            <div class="card-body d-flex flex-column justify-content-center align-items-center">
                                <form method="POST" >
                                <h1 class="display-2 text-primary"><span class=""> <img height="250" width="250" src="back/<?PHP echo $row['image']; ?> " alt=""> </span></h1>
                                <h4 class="card-title text-primary"><?php echo $row["nom"]?> </h4>
                                <p class="card-text" ><?php echo $row["prix"];?> dt</p>
                                <input name="pid" value="<?php echo $row["reference"]?>" hidden>
                                 <input name="pprice" value="<?php echo $row["prix"]?>" hidden>

                                    <button type="submit" name="add"><a  class="btn btn-primary mt-auto">ajouter panier</a> </button>
                                </form>
                            </div>
                        </div>
                    </div>
                        <?php
                    }
                    ?>
                </div>
            </div>
        </div>
    </section>

    <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">Modal title</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                    <tr>
                        <th>image</th>
                        <th>nom</th>
                        <th>quantité</th>
                        <th>prix </th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>

                <?php
                foreach($produits as $row)
                {
                    $produit=$panier_ligneC->get_product_name($row['idproduit']);
                    $row2 = mysqli_fetch_array($produit,MYSQLI_BOTH);
                    $image= $panier_ligneC->get_product_image($row['idproduit']);
                    foreach ($image as $row3){
                        $img=$row3['image'];
                        $nom=$row3['nom'];
                }
                    ?>
                <tr>
                    <div class="modal-body">
                        <form method="POST">

                            <td> <img height="50" width="50" src="back/<?PHP echo $img; ?> " alt=""> </td>
                           <span "><?php echo $row2[0]; ?> </span>
                            <td><span  ><?php echo $nom; ?></span></td>
                            <td> <span><?php echo $row["quantite"]; ?></span></td>
                            <td> <span><?php echo $row["prixunitaire"];?></span></td>
                            <input  name="idlp"  value="<?php echo $row['idlp']; ?>" hidden>
                            <td><button name="dell" class="btn btn-warning ml-2">delete </button></td>
                        </form>
                    </div>
                </tr>
                    <?php
                }
                ?>
                    </tbody>
                </table>
                          totale :  <?php echo $totalep; ?> dt
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>

            </div>
        </div>
    </div>

</main>
<footer id="footer" class="bg-dark text-light py-5">
    <div class="container py-5">
        <div class="row">
            <div class="col-6 col-md-6 col-lg-3 mb-2">
                <h6 class="text-uppercase">Tools</h6>
                <ul class="nav flex-column">
                    <li><a class="text-white" target="ext" rel="nofollow" href="https://themestr.app" title="Bootstrap theme builder">Themestr.app</a></li>
                    <li><a class="text-white" target="ext" rel="nofollow" href="http://themes.guide" title="Bootstrap free and pro themes">Themes.guide</a></li>
                    <li><a class="text-white" target="ext" rel="nofollow" href="http://codeply.com" title="Prototype and edit code for Bootstrap and other responsive frameworks">Codeply</a></li>
                    <li><a class="text-white" target="ext" rel="nofollow" href="http://bootply.com">Bootply</a></li>
                </ul>
            </div>
            <div class="col-6 col-md-6 col-lg-3 mb-2">
                <h6 class="text-uppercase">More</h6>
                <ul class="nav flex-column">
                    <li><a class="text-white" target="_new" href="http://wdstack.com" title="The top projects, tools and apps for Web developers">WDStack</a></li>
                    <li><a class="text-white" target="_new" href="http://theme.cards">Theme.cards</a></li>
                    <li><a class="text-white" target="_new" href="http://www.bootbundle.com">BootBundle</a></li>
                    <li><a class="text-white" target="_new" title="Learn about Bootstrap 4 using this free theme" href="http://bootstrap4.guide">Bootstrap4.guide</a></li>
                </ul>
            </div>
            <div class="col-12 col-md-12 col-lg-6 mb-2 text-right">
                <h6 class="text-uppercase">Follow</h6>
                <ul class="nav float-right">
                    <li><a class="text-white mr-2" rel="nofollow" href="http://twitter.com/ThemesGuide" title="Follow on Twitter"><i class="h1 fa fa-fw fa-twitter fa-2x ion-logo-twitter"></i></a></li>
                    <li><a class="text-white mr-2" rel="nofollow" href="https://www.facebook.com/codeply" title="Follow on Facebook"><i class="h1 fa fa-fw fa-facebook fa-2x ion-logo-facebook"></i></a></li>
                    <li><a class="text-white mr" rel="nofollow" href="https://github.com/ThemesGuide/bootstrap-themes" title="Follow on GitHub"><i class="h1 fa fa-fw fa-facebook fa-2x ion-logo-github"></i></a></li>
                </ul>
            </div>
        </div>
        <!--/row-->
    </div>
</footer>
<script src="//ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/popper.js/1.13.0/umd/popper.min.js"></script>
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<script src="scripts.js"></script>
</body>
</html>
<?php
if(isset($_POST['add'])){
    if (isset($_SESSION['id']) && isset($_SESSION['username'] ))
    {
        $panier_ligne=new panier_ligne($_SESSION['id'],$_POST["pid"],1,$_POST["pprice"]);

        $panier_ligneC->ajouterpanier_ligne($panier_ligne);

        $produits2=$panier_ligneC->get_produit($_SESSION['id']);
        $totale=0;
        $nbroduit=0;
        foreach($produits2 as $row5){
            $nbroduit=$nbroduit+$row5["quantite"];
            $totale=$totale+($row5["prixunitaire"]*$row5["quantite"]);
            ?>
            <script>
                window.location.replace("produit.php");
            </script>
            <?php
        }

        $panierC->modifierPanier($_SESSION['id'],$nbroduit,$totale);
    }

    else {
        ?>
        <script>
            window.location.replace("login.php");
        </script>
        <?php

    }

}

if(isset($_POST['dell'])){
    if (isset($_SESSION['id']) && isset($_SESSION['username'] ))
    {
        $panier_ligneC->supprimerpanier_ligne($_POST['idlp']);

        $produits2=$panier_ligneC->get_produit($_SESSION['id']);
        $totale=0;
        $nbroduit=0;
        foreach($produits2 as $row5){
            $nbroduit=$nbroduit+$row5["quantite"];
            $totale=$totale+($row5["prixunitaire"]*$row5["quantite"]);

        }

        $panierC->modifierPanier($_SESSION['id'],$nbroduit,$totale);

        ?>
        <script>
            window.location.replace("produit.php");
        </script>
        <?php
    }

    else {
        ?>
        <script>
            window.location.replace("login.php");
        </script>
        <?php

    }
}
?>
