<?PHP
include "../../core/produitC.php";
$produitC=new produitC();
if (isset($_GET["reference"])){
	$produitC->supprimerproduit($_GET["reference"]);
	header('Location: afficherproduit.php');
}

?>