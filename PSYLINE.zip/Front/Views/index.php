<?php session_start();
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fresca Bootstrap 4 Theme Full Screen</title>
    <meta name="generator" content="Themestr.app">
    <link rel="icon" href="http://themes.guide/favicon.ico" type="image/x-icon" />
    <link rel="shortcut icon" href="http://themes.guide/favicon.ico" type="image/x-icon" />
    <meta property="og:image" name="twitter:image" content="http://bootstrap.themes.guide/assets/ss_fresca.png">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/3.0.0/css/ionicons.css" rel="stylesheet">
    <link href="./theme.css" rel="stylesheet">
    <link href="./template.css" rel="stylesheet">
  </head>
  
  <body  data-target="#navbar1" data-offset="60">
    <header class="bg-primary">
    </header>
        <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-primary" id="navbar1">
        <div class="container">
            <a class="navbar-brand mr-1 mb-1 mt-0" href="./index.php">PsyLine</a>
            <div class="navbar-collapse collapse justify-content-center" id="collapsingNavbar">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="../../diagnostic.php">
                          Diagnostic
                        </a>
                       
                        
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link" href="../../rdv/views/connexion.html">
                        Rendez-Vous
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link" href="produit.php">Produit</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="./forum/index.php">
                        Forum
                        </a>
                    </li>
                </ul>
                <ul class="navbar-nav ml-auto">
                    
                        
                        
                    </li>
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                            <?php
                            if (isset($_SESSION['id']) && isset($_SESSION['username'] ))
                            { ?>
                            <span style="display: inline-block;"><a class="nav-link" href="Logout.php">Logout (<?php echo $_SESSION['username']; ?>)</a>
                                <a href="cart.php" data-toggle="modal" data-target="#exampleModalCenter"> <i class="icofont-dart icofont-1x" style="color: red;" >cart</i> </a>  </span>
                            <?php }
                            else {
                        ?>
                            <a class="nav-link" href="Login.php">Login</a>
                            <?php
                        }
                        ?>
                        </li>
                    </ul>
                    
                    
                    <li class="nav-item">
                        <a class="nav-link" href="../../Gestion/Views/Inscription.php">Créer un Compte</a>
                    </li>
                    
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDd" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          More
                        </a>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDd">
                            <a class="dropdown-item px-2" href="#more">Facebook</a>
                            <a class="dropdown-item px-2" href="#more">Contactez-nous</a>

                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </nav> 
    <main>
        <section  class="container">
            <div style="margin-top:50px" class="jumbotron w-100 py-5 mx-auto">
                <div style="display: flex;
                justify-content: space-between;">>
                    <div>
                    <img src="../../Back/psyline.png" style="margin-right:30px" width=170>
                </div>
                <div>
                <h1>PSYLINE</h1>
                <h4>Site Web dédié à la santé mentale</h4>
                <p class="lead">
                    Ce site web a été créé dans le but d'offrir un portail pour ceux qui ont en besoin afin de se soigner et ainsi que de bien s'informer
                    sur la santé mentale, surtout qu'il s'agit toujours d'un sujet tabou dans notre pays. Docteur X reste à votre disposition pour vous renseignez
                    ainsi que vous consultez si necessaire. En attendant, Veuillez découvrir ce que le site a à offrir. 
                </p>
                </div>
                </div>
            </div>
            
        </section>
        <section  class="container">
        <div style="display: flex;
        justify-content: space-between;">
            <div style="margin:20px" class="card h-100">
                <div style="height:400px;width:300px;" class="card-body d-flex flex-column justify-content-center align-items-center">
                    <h1 class="display-2 text-primary"><span class="ion ion-ios-snow-outline"></span></h1>
                    <h4 class="card-title text-primary">Diagnostic En Ligne</h4>
                    <p class="card-text">Passez un questionnaire en ligne pour tester votre santé mentale. Gardez et comparez vos résultats . 100% Gratuit!</p>
                    <a href="../../diagnostic.php" class="btn btn-primary mt-auto">Passer le Questionnaire</a>
                </div>
            </div>
            <div style="margin:20px;" class="card h-100">
                <div style="height:400px;width:300px;" class="card-body d-flex flex-column justify-content-center align-items-center">
                    <h1 class="display-2 text-primary"><span class="ion ion-ios-snow-outline"></span></h1>
                    <h4 class="card-title text-primary">Essayez Nos Produits</h4>
                    <p class="card-text">Nous vendons des produits paramédicaus ainsi que des les livres qui sont sûrs de vous aidez!</p>
                    <a href="produit.php" class="btn btn-primary mt-auto">Jetez Un coup d'oeil!</a>
                </div>
            </div>
            <div style="margin:20px" class="card h-100">
                <div style="height:400px;width:300px;" class="card-body d-flex flex-column justify-content-center align-items-center">
                    <h1 class="display-2 text-primary"><span class="ion ion-ios-snow-outline"></span></h1>
                    <h4 class="card-title text-primary">Forum</h4>
                    <p class="card-text">Visitez le Forum pour des conseils instructifs et des points de vue d'autres patients.</p>
                    <a href="./forum/index.php" class="btn btn-primary mt-auto">Button</a>
                </div>
            </div>
        </div>
            
            
               
        </section>
        
    </main>
        <footer id="footer" class="bg-dark text-light py-5">
            <center>
                Pour plus d'informations ,Veuillez nous contacter sur : +21622555555
            </center>
        </footer> 
    <script src="jquery.min.js"></script>
    <script src="popper.min.js"></script>
    <script src="bootstrap.min.js"></script>
    <script src="scripts.js"></script>
</body>
</html>