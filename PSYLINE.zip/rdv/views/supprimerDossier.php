<?php
include "../controller/DossierC.php";
include_once "../Model/Dossier.php";

$id = $_GET["id"];

$dossier = new DossierC();
$dossier->supprimerDossier($id);



echo "<script>window.open('afficherDossier.php?id=deletedSucceed','_self')</script>";
