
<?php
include "../controller/DossierC.php";
include_once "../Model/Dossier.php";
$id = $_GET["id"];

if (isset($_POST['submit'])) {
    $dossier = new Dossier($_POST["nom"], $_POST["prenom"], $_POST["medicament"]);
    $dossierCore = new DossierC();
    $dossierCore->modifierDossier($dossier, $id);

    
        
    echo "<script>window.open('afficherDossier.php?id=updateSucceed','_self')</script>";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
  <title>Document</title>
</head>
<body>
  
<div class="container">

<a href="afficherRendezvous.php" class="btn btn-primary mt-3">afficher rendez-vous</a>


<?php



$id = $_GET["id"];

$dossierCore = new DossierC();
$list = $dossierCore->afficherDossierParId($id);

foreach ($list as $row)

    ?>
<form class="pt-5" action="modifierDossier.php?id=<?php echo $id ?>" method="POST">
  <div class="form-group">
    <label for="exampleInputEmail1">nom</label>
    <input type="text" class="form-control" id="exampleInputEmail1"   placeholder="<?php echo $row['nom']; ?>" name="nom">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">prenom</label>
    <input type="text" class="form-control" id="exampleInputPassword1"  placeholder="<?php echo $row['prenom']; ?>" name="prenom">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">medicament</label>
    <input type="text" class="form-control" id="exampleInputPassword1"  placeholder="<?php echo $row['medicament']; ?>" name="medicament">
  </div>
  
  <button type="submit" class="btn btn-success mt-5" name="submit">Submit</button>
</form>


</div>


</body>
</html>