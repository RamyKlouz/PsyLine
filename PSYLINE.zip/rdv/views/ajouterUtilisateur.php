<?php

include_once '../Controller/UtilisateurC.php';
include_once '../Model/Utilisateurs.php';


$nom=$_POST['nom'];
$prenom=$_POST['prenom'];
$date=$_POST['date'];
$heure=$_POST['heure'];

$user=new Utilisateurs($nom,$prenom,$date,$heure);
$UserC=new UtilisateurC();
$UserC->AjouterPatient($user);
header('Location:afficherUtilisateur.php');

?>