<?php

require "fpdf/fpdf.php";
$db = new PDO('mysql:host=localhost;dbname=rdv', 'root', '');
class myPDF extends FPDF
{
    function header()
    {
        $this->SetFont("Arial", 'B', 14);
        $this->Cell(50, 5, "Rendez-vous");
        $this->LN();
    }
    function headerTable()
    {
        $this->SetFont("Times", 'B', 12);
        $this->Cell(50, 30, "id", 1, 0, 'C');
        $this->Cell(50, 30, "Nom", 1, 0, 'C');
        $this->Cell(50, 30, "Prenom", 1, 0, 'C');
        $this->Cell(50, 30, "Date", 1, 0, 'C');
        $this->Cell(50, 30, "Heure", 1, 0, 'C');

        $this->LN();
        
    }
    function viewTable($db)
    {
        $this->SetFont("Times", "", 12);

        $stmt = $db->query("select * from offre");
        while ($data = $stmt->fetch()) {
            $this->Cell(50, 10, $data["id"], 1, 0, 'C');
            $this->Cell(50, 10, $data["name"], 1, 0, 'C');
            $this->Cell(50, 10, $data["type"], 1, 0, 'C');
            $this->Cell(50, 10, $data["location"], 1, 0, 'C');
            $this->Cell(50, 10, $data["prixsimple"], 1, 0, 'C');
            $this->Cell(50, 10, $data["prixdouble"], 1, 0, 'C');
            $this->Cell(50, 10, $data["prixfamily"], 1, 0, 'C');
            $this->Cell(50, 10, $data["date1"], 1, 0, 'C');
            $this->Cell(50, 10, $data["date2"], 1, 0, 'C');
            $this->Cell(50, 10, $data["description"], 1, 0, 'C');
            $this->Ln();
        }
    }
}

$pdf = new myPDF();


$pdf->AliasNbPages();
$pdf->AddPage("L", "A4", 0);
$pdf->headerTable();
$pdf->viewTable($db);
$pdf->Output();