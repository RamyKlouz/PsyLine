

<form action="ajouterUtilisateur.php" method="POST">
    <table border="1" align="center">

        <tr>
            <td rowspan='3' colspan='1'>Fiche Personnelle</td>
            <td>
                <label for="nom">Nom:
                </label>
            </td>
            <td><input type="text" name="nom" id="nom" maxlength="20"></td>
        </tr>
        <tr>
            <td>
                <label for="prenom">Prénom:
                </label>
            </td>
            <td><input type="text" name="prenom" id="prenom" maxlength="20"></td>
        </tr>

        <tr>
            <td>
                <label for="email">Adresse mail:
                </label>
            </td>
            <td>
                <input type="email" name="email" id="email" pattern=".+@gmail.com|.+@esprit.tn">
            </td>
        </tr>
        <tr>
            <td rowspan='2' colspan='1'>Information de Connexion</td>
            <td>
                <label for="login">Login:
                </label>
            </td>
            <td>
                <input type="text" name="login" id="login" >
            </td>
        </tr>
        <tr>
            <td>
                <label for="pass">Mot de passe:
                </label>
            </td>
            <td>
                <input type="password" name="pass" id="pass">
            </td>
        </tr>

        <tr>
            <td></td>
            <td>
                <input type="submit" value="Envoyer">
            </td>
            <td>
                <input type="reset" value="Annuler" >
            </td>
        </tr>
    </table>
</form>
</body>
</html>