<?php

require "fpdf/fpdf.php";
$db = new PDO('mysql:host=localhost;dbname=rdv', 'root', '');
class myPDF extends FPDF
{
    function header()
    {
        $this->SetFont("Arial", 'B', 14);
        $this->Cell(50, 5,  "Dossier Medical",0,0,"C");
        $this->LN();
    }
    function headerTable()
    {
        $this->SetFont("Times", 'B', 12);
        $this->Cell(50, 30, "ID", 1, 0, 'C');
        $this->Cell(50, 30, "nom", 1, 0, 'C');
        $this->Cell(50, 30, "prenom", 1, 0, 'C');
        $this->Cell(50, 30, "medicament", 1, 0, 'C');
        $this->Ln();

    }
    function viewTable($db)
    {
        $this->SetFont("Times", "", 12);

        $stmt = $db->query("select * from dossier");
        while ($data = $stmt->fetch()) {
            $this->Cell(50, 30, $data["id"], 1, 0, 'C');
            $this->Cell(50, 30, $data["nom"], 1, 0, 'C');
            $this->Cell(50, 30, $data["prenom"], 1, 0, 'C');
            $this->Cell(50, 30, $data["medicament"], 1, 0, 'C');

            $this->Ln();
        }
    }
}

$pdf = new myPDF();

$pdf->AliasNbPages();
$pdf->AddPage("L", "A4", 0);
$pdf->headerTable();
$pdf->viewTable($db);
$pdf->Output();

