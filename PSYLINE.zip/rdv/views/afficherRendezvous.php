<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SB Admin 2 - Dashboard</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

    <title>Document</title>
</head>
<body>
<a href="ajouterDossier.php" class="btn btn-primary mt-3">ajouter dossier</a>

<div class="container">
<h1>Afficher rendez vous</h1>	
    <table class="table">
        <thead class="thead-dark">
                <tr>
                    <th>Id</th>
                    <th>Nom</th>
                    <th>Prenom</th>
                    <th>Date</th>
                    <th>Heure</th>
                </tr>
    </thead >
    
                <?PHP
                include '../Controller/UtilisateurC.php';
                $userC=new UtilisateurC();
                $users=$userC->AfficherUtilisateurs();
                    foreach($users as $user){
                ?>
                    <tr>
                        <td><?PHP echo $user['id']; ?></td>
                        <td><?PHP echo $user['Nom']; ?></td>
                        <td><?PHP echo $user['Prenom']; ?></td>
                        <td><?PHP echo $user['Date']; ?></td>
                        <td><?PHP echo $user['Heure']; ?></td>
                        
                    </tr>
                <?PHP
                    }
                ?>
            </table>
                </div>
    
</body>
</html>