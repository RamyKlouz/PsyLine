<?php
include "../controller/UtilisateurC.php";
include "../Model/Utilisateur.php";

$id = $_GET["id"];

$user = new UtilisateurC();
$user->supprimerPatient($id);



echo "<script>window.open('afficherUtilisateur.php?id=deletedSucceed','_self')</script>";
