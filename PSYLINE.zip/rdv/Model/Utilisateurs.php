<?PHP
class Utilisateurs{
    private  $nom = null;
    private  $prenom = null;
    private $date = null;
    private  $heure = null;

    function __construct( $nom, $prenom, $date, $heure){

        $this->nom=$nom;
        $this->prenom=$prenom;
        $this->date=$date;
        $this->heure=$heure;
    }

    /**
     * @return null
     */
    

    /**
     * @param null $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return null
     */
    public function getNom()
    {
        return $this->nom;
    }

    /**
     * @param null $nom
     */
    public function setNom($nom)
    {
        $this->nom = $nom;
    }

    /**
     * @return null
     */
    public function getPrenom()
    {
        return $this->prenom;
    }

    /**
     * @param null $prenom
     */
    public function setPrenom($prenom)
    {
        $this->prenom = $prenom;
    }

    /**
     * @return null
     */
    public function getDate()
    {
        return $this->date;
    }

    /**
     * @param null $date
     */
    public function setDate($date)
    {
        $this->email = $date;
    }

    /**
     * @return null
     */
    public function getHeure()
    {
        return $this->heure;
    }

    /**
     * @param null $heure
     */
    public function setHeure($heure)
    {
        $this->heure = $heure;
    }

}
?>