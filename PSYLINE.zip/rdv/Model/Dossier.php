<?PHP
class Dossier{
    private  $nom = null;
    private  $prenom = null;
    private $medicament = null;

    function __construct( $nom, $prenom, $medicament){

        $this->nom=$nom;
        $this->prenom=$prenom;
        $this->medicament=$medicament;
    }

    /**
     * @return null
     */
    

    /**
     * @param null $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return null
     */
    public function getNom()
    {
        return $this->nom;
    }

    /**
     * @param null $nom
     */
    public function setNom($nom)
    {
        $this->nom = $nom;
    }

    /**
     * @return null
     */
    public function getPrenom()
    {
        return $this->prenom;
    }

    /**
     * @param null $prenom
     */
    public function setPrenom($prenom)
    {
        $this->prenom = $prenom;
    }

   

    /**
     * @return null
     */
    public function getmedicament()
    {
        return $this->medicament;
    }

    /**
     * @param null $medicament
     */
    public function setmedicament($medicament)
    {
        $this->medicament = $medicament;
    }

}
?>