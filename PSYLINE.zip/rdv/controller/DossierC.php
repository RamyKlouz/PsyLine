<?php
require '../config.php';
require_once '../Model/Dossier.php';
class DossierC
{


    /////read
 public function AfficherDossier()
 {
     $sql='select * from dossier';
     $db = config::getConnexion();
try {$list= $db->query($sql);

return $list;}
catch (Exception $e){
    die('Erreur: '.$e->getMessage());
}}
//CRUD   =Create/read/update/delete
//
/////Create
public function AjouterDossier($Dossier)

 {  $db = config::getConnexion();
     $sql="INSERT INTO dossier (nom, prenom, medicament) 
			VALUES (:nom,:prenom,:medicament)";
try { $query=$db->prepare($sql);
    $query->bindValue('nom',$Dossier->getNom());
    $query->bindValue('prenom',$Dossier->getPrenom());
    $query->bindValue('medicament',$Dossier->getMedicament());

    $query->execute();

}
catch (Exception $e){
    echo 'Erreur: '.$e->getMessage();
}

 }
 public function supprimerDossier($id)
{
    $sql = "DELETE FROM dossier where id= :id";
    $db = config::getConnexion();
    $req = $db->prepare($sql);
    $req->bindValue(':id', $id);
    try {
        $req->execute();
    } catch (Exception $e) {
        die('Erreur: ' . $e->getMessage());
    }
}

public function modifierDossier($dossier,$id){
    $sql = "UPDATE dossier SET nom=:nom,prenom=:prenom,medicament=:medicament where id=:id";
    $db = config::getConnexion();
    try {
        $req = $db->prepare($sql);

        $nom = $dossier->getNom();
        $prenom = $dossier->getPrenom();
        $medicament = $dossier->getMedicament();
       


        $req->bindValue(':nom', $nom);
        $req->bindValue(':prenom', $prenom);
        $req->bindValue(':medicament', $medicament);
        $req->bindValue(':id', $id);


        $req->execute();

    } catch (Exception $e) {
        echo " Erreur ! " . $e->getMessage();
    }
}
public function afficherDossierParId($id){
    $sql = "SELECT * FROM dossier where id=$id";
    $db = config::getConnexion();
    try {

        $liste = $db->query($sql);
        return $liste;
    } catch (Exception $e) {
        die('Erreur: ' . $e->getMessage());
    } 
}



}