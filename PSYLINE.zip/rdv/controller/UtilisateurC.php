<?php
require '../config.php';
require_once '../Model/Utilisateurs.php';
class UtilisateurC
{


    /////read
 public function AfficherUtilisateurs()
 {
     $sql='select * from patient';
     $db = config::getConnexion();
try {$list= $db->query($sql);

return $list;}
catch (Exception $e){
    die('Erreur: '.$e->getMessage());
}}
//CRUD   =Create/read/update/delete
//
/////Create
public function AjouterPatient($Utilisateurs)

 {  $db = config::getConnexion();
     $sql="INSERT INTO patient (nom, prenom, date, heure) 
			VALUES (:nom,:prenom,:date, :heure)";
try { $query=$db->prepare($sql);
    $query->bindValue('nom',$Utilisateurs->getNom());
    $query->bindValue('prenom',$Utilisateurs->getPrenom());
    $query->bindValue('date',$Utilisateurs->getDate());
    $query->bindValue('heure',$Utilisateurs->getHeure());

    $query->execute();

}
catch (Exception $e){
    echo 'Erreur: '.$e->getMessage();
}

 }
 public function supprimerPatient($id)
{
    $sql = "DELETE FROM patient where id= :id";
    $db = config::getConnexion();
    $req = $db->prepare($sql);
    $req->bindValue(':id', $id);
    try {
        $req->execute();
    } catch (Exception $e) {
        die('Erreur: ' . $e->getMessage());
    }
}

public function modifierPatient($user,$id){
    $sql = "UPDATE patient SET Nom=:nom,Prenom=:prenom,Date=:date,Heure=:heure where id=:id";
    $db = config::getConnexion();
    try {
        $req = $db->prepare($sql);

        $nom = $user->getNom();
        $prenom = $user->getPrenom();
        $date = $user->getDate();
        $heure = $user->getHeure();
       


        $req->bindValue(':nom', $nom);
        $req->bindValue(':prenom', $prenom);
        $req->bindValue(':date', $date);
        $req->bindValue(':heure', $heure);
        $req->bindValue(':id', $id);


        $req->execute();

    } catch (Exception $e) {
        echo " Erreur ! " . $e->getMessage();
    }
}
public function afficherUtilisateurParId($id){
    $sql = "SELECT * FROM patient where id=$id";
    $db = config::getConnexion();
    try {

        $liste = $db->query($sql);
        return $liste;
    } catch (Exception $e) {
        die('Erreur: ' . $e->getMessage());
    } 
}



}