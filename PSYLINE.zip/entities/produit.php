<?PHP
class Produit{
	private $reference;
	private $nom;
	private $quantite;
    private $prix;
    private $image;
	function __construct($nom,$quantite,$prix,$image){
		$this->nom=$nom;
		$this->quantite=$quantite;
        $this->prix=$prix;
        $this->image=$image;
		
	}
	
	function getreference(){
		return $this->reference;
	}
	function getnom(){
		return $this->nom;
	}
	function getquantite(){
		return $this->quantite;
	}
	function getprix(){
		return $this->prix;
    }
    function getimage(){
		return $this->image;
	}



	function setreference($reference){
		$this->reference=$reference;
	}
	function setnom($nom){
		$this->nom=$nom;
	}
	function setquantite($quantite){
		$this->quantite=$quantite;
	}
	function setprix($prix){
		$this->prix=$prix;
    }
    function setimage($image){
		$this->image=$image;
	}
	
}

?>