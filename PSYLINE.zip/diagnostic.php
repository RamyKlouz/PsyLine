<?php
include './Front/functions.php';

// Connect to MySQL database
$pdo = pdo_connect_mysql();
$stmt = $pdo->prepare('SELECT * FROM questions ORDER BY id');
$stmt->execute();
// Fetch the records so we can display them in our template.
$questions = $stmt->fetchAll(PDO::FETCH_ASSOC);
// Get the total number of contacts, this is so we can determine whether there should be a next and previous button
$num_questions = $pdo->query('SELECT COUNT(*) FROM questions')->fetchColumn();
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fresca Bootstrap 4 Theme Full Screen</title>
    <meta name="generator" content="Themestr.app">
    <link rel="icon" href="http://themes.guide/favicon.ico" type="image/x-icon" />
    <link rel="shortcut icon" href="http://themes.guide/favicon.ico" type="image/x-icon" />
    <meta property="og:image" name="twitter:image" content="http://bootstrap.themes.guide/assets/ss_fresca.png">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/3.0.0/css/ionicons.css" rel="stylesheet">
    <link href="./theme.css" rel="stylesheet">
    <link href="./template.css" rel="stylesheet">

  </head>
  
  <body  data-target="#navbar1" data-offset="60">
    <header class="bg-primary">
    </header>
    <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-primary" id="navbar1">
        <div class="container">
            <a class="navbar-brand mr-1 mb-1 mt-0" href="./front/views/index.php">PsyLine</a>
            <div class="navbar-collapse collapse justify-content-center" id="collapsingNavbar">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="../../diagnostic.php">
                          Diagnostic
                        </a>
                       
                        
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link" href="../../rdv/views/connexion.html">
                        Rendez-Vous
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link" href="produit.php">Produit</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="./forum/index.php">
                        Forum
                        </a>
                    </li>
                </ul>
                <ul class="navbar-nav ml-auto">
                    
                        
                        
                    </li>
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                            <?php
                            if (isset($_SESSION['id']) && isset($_SESSION['username'] ))
                            { ?>
                            <span style="display: inline-block;"><a class="nav-link" href="Logout.php">Logout (<?php echo $_SESSION['username']; ?>)</a>
                                <a href="cart.php" data-toggle="modal" data-target="#exampleModalCenter"> <i class="icofont-dart icofont-1x" style="color: red;" >cart</i> </a>  </span>
                            <?php }
                            else {
                        ?>
                            <a class="nav-link" href="Login.php">Login</a>
                            <?php
                        }
                        ?>
                        </li>
                    </ul>
                    
                    
                    <li class="nav-item">
                        <a class="nav-link" href="../../Gestion/Views/Inscription.php">Créer un Compte</a>
                    </li>
                    
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDd" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          More
                        </a>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDd">
                            <a class="dropdown-item px-2" href="#more">Facebook</a>
                            <a class="dropdown-item px-2" href="#more">Contactez-nous</a>

                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </nav>  
    <main>

        <section style="margin: 100px;align-content: center;" id="cards" class="container pb-5">
            <div class="d-flex my-3">
                <div class="jumbotron w-100 py-5 mx-auto">
                    <form  name="questionnaire">
                    <?php $j=1;$l=$j+1; ?>
                    <?php foreach ($questions as $question): ?>
                    <h1 >Question n°<?=$j ?></h1>
                    
                    <h4><?=$question['question']?></h4>
                    <p class="lead">
                        Choisissez une seule réponse qui convient le mieux à votre situation.
                    </p>
                                          
                        <input type="radio" id="q<?php echo $j;?>1" name="q<?php echo $j;?>" value="1" onclick="myFunction('q<?php echo $j;?>1','q<?php echo $j;?>2','q<?php echo $j;?>3','q<?php echo $j;?>4','text<?php echo $j;?>')">
                        <label style="width:200px;" class="lead" for="q<?php echo $j;?>1"><?=$question['a1']?>   </label>
                        <input type="radio" id="q<?php echo $j;?>2" name="q<?php echo $j;?>" value="3" onclick="myFunction('q<?php echo $j;?>1','q<?php echo $j;?>2','q<?php echo $j;?>3','q<?php echo $j;?>4','text<?php echo $j;?>')">
                        <label style="width:200px;" class="lead" for="q<?php echo $j;?>2"><?=$question['a2']?>   </label>
                        <input type="radio" id="q<?php echo $j;?>3" name="q<?php echo $j;?>" value="6" onclick="myFunction('q<?php echo $j;?>1','q<?php echo $j;?>2','q<?php echo $j;?>3','q<?php echo $j;?>4','text<?php echo $j;?>')">
                        <label style="width:200px;" class="lead" for="q<?php echo $j;?>3"><?=$question['a3']?>   </label>
                        <input type="radio" id="q<?php echo $j;?>4" name="q<?php echo $j;?>" value="10" onclick="myFunction('q<?php echo $j;?>1','q<?php echo $j;?>2','q<?php echo $j;?>3','q<?php echo $j;?>4','text<?php echo $j;?>')">
                        <label style="width:200px;" class="lead" for="q<?php echo $j;?>4"><?=$question['a4']?>   </label> <br>
                        <p id="text<?php echo $j;?>" style="color:grey;font-style: italic;display:none;">Votre réponse vaut </p>
                        <?php $j++;$l=$j+1; ?>
                        <hr style="width:100%;text-align:left;margin-left:0">
                        <?php endforeach; ?>
                        <?php $j--;?>
                        <button type="button" onclick="Ver()" class="btn btn-outline-info">Valider</button>
                    </form>
                    <div id="scora" style="display:none;">
                        <h2>Votre Score est ...</h2>
                        <h1 style="text-align: center;"><span id="scori" style="color:green;"></span>/10</h1>
                        <h3 id="scoretext" style="text-align: center;">Vous avez une très bonne santé mentale.</h3>
                        <h4 style="text-align: center;">Voulez-vous enregistrer votre résultat ?</h4>
                        <form action="createscore.php" method="post">
                        <div class="form-group row">
	                        <label class="col-md-2 col-form-label form-control-label text-muted">Name</label>
	                        <div class="col-md-4">
	                        	<input class="form-control" name="name" type="text" value="Sam" oninvalid="this.setCustomValidity('Veuillez remplir l\'ID')" oninput="setCustomValidity('')" required>
	                        </div>
	                        <label class="col-md-1 col-form-label form-control-label text-muted">Score</label>
	                        <div class="col-md-5">
	                        	<input id="inputscore" name="score" class="form-control" step="0.01" type="number" readonly>
	                        </div>
                        </div>
                        <div class="form-group row">
	                        <label class="col-md-2 col-form-label form-control-label text-muted">Date</label>
	                        <div class="col-md-4">
	                        	<input class="form-control" name="created" type="datetime-local" name="created" value="<?=date('Y-m-d\TH:i')?>">
	                        </div>
	                        <button style="margin-left:106px;width:417px" type="submit" class="btn btn-outline-info">Enregistrer</button>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
            
            
            
        </section>
        
    </main>
        <footer id="footer" class="bg-dark text-light py-5">
          
        </footer> 
    <script src="jquery.min.js"></script>
    <script src="popper.min.js"></script>
    <script src="bootstrap.min.js"></script>
    <script src="scripts.js"></script>
    <script>
        function myFunction(id1,id2,id3,id4,id5) {
        var checkBox1 = document.getElementById(id1);
        var checkBox2 = document.getElementById(id2);
        var checkBox3 = document.getElementById(id3);
        var checkBox4 = document.getElementById(id4);
        var text = document.getElementById(id5).innerHTML;
        var t = document.getElementById(id5);
        var b = ' points.';
        var c = ' point.';
            if (checkBox1.checked == true){
            text="Votre réponse vaut ";
            let a = text.concat(checkBox1.value,c);
            t.innerHTML=a;
            t.style.display = "block";
        } else if (checkBox2.checked == true){
            text="Votre réponse vaut " ;
            let a = text.concat(checkBox2.value,b);
            t.innerHTML=a;
            t.style.display = "block";
        } else if (checkBox3.checked == true){
            text="Votre réponse vaut " ;
            let a = text.concat(checkBox3.value,b);
            t.innerHTML=a;
            t.style.display = "block";
        } else if (checkBox4.checked == true){
            text="Votre réponse vaut " ;
            let a = text.concat(checkBox4.value,b);
            t.innerHTML=a;
            t.style.display = "block";
        }else {
            t.style.display = "none";
        }
        }
        function Ver(){
            var max = <?php echo $j;?>;
            var x=true;

            for(var i=1; i<=max; i++) {
                console.log(i+" let's try");
                if (Verif("text"+i))
                  x=false;
            }
            if (!x)
                alert ("SVP répondez à toutes les questions.");
            else {
            document.getElementById("scora").style.display="block";
            document.getElementById("inputscore").value=parseFloat(moyenne().toFixed(2));
            document.getElementById("scori").innerHTML=moyenne().toFixed(2);
            if (moyenne() < 8 && moyenne() >= 5){
                document.getElementById("scori").style.color="lime";
                document.getElementById("scoretext").innerHTML="Vous allez plutôt bien mais vous devriez visiter un spécialiste régulièrement.";
            } else if (moyenne() < 5 && moyenne() >= 3) {
                document.getElementById("scori").style.color="orange";
                document.getElementById("scoretext").innerHTML="Votre situation est inquiétante, veuillez visiter un spécialiste."
            }  else if (moyenne() < 3) {
                document.getElementById("scori").style.color="red";
                document.getElementById("scoretext").innerHTML="Votre situation est urgente, veuillez visiter un spécialiste immédiatement."
            }
            }

        }
        function Verif(id){
            var t = document.getElementById(id);
            if (t.style.display == "none"){
                return true;
                console.log(" is clear");
                
            } else return false;  
        
        }
        function moyenne() {
            var max = <?php echo $j;?>;
            var s=0;
            for(var i=1; i<=max; i++) {
                console.log("calcul...");
                var a = document.forms.questionnaire["q"+i].value;
                console.log(a);
                var b=parseInt(a);
                s=s+b;
            }
            return s/max;
            
        }
    </script>
</body>
</html>