<?php
include './Front/functions.php';
$pdo = pdo_connect_mysql();
$msg = '';
// Check that the contact ID exists
if (isset($_GET['id'])) {
    // Select the record that is going to be deleted
    $stmt = $pdo->prepare('SELECT * FROM scores WHERE id = ?');
    $stmt->execute([$_GET['id']]);
    $score = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$score) {
        exit('Contact doesn\'t exist with that ID!');
    }
    // Make sure the user confirms before deletion
    if (isset($_GET['confirm'])) {
        if ($_GET['confirm'] == 'yes') {
            // User clicked the "Yes" button, delete record
            $stmt = $pdo->prepare('DELETE FROM scores WHERE id = ?');
            $stmt->execute([$_GET['id']]);
            $msg = 'Vous avez supprimé le résultat!';
            header( "refresh:2;url=history.php" );
        } else {
            // User clicked the "No" button, redirect them back to the read page
            header('Location: history.php');
            exit;
        }
    }
} else {
    exit('No ID specified!');
}
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fresca Bootstrap 4 Theme Full Screen</title>
    <meta name="generator" content="Themestr.app">
    <link href="./back/styletables.css" rel="stylesheet" type="text/css">
    <link rel="icon" href="http://themes.guide/favicon.ico" type="image/x-icon" />
    <link rel="shortcut icon" href="http://themes.guide/favicon.ico" type="image/x-icon" />
    <meta property="og:image" name="twitter:image" content="http://bootstrap.themes.guide/assets/ss_fresca.png">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/3.0.0/css/ionicons.css" rel="stylesheet">
    <link href="./theme.css" rel="stylesheet">
    <link href="./template.css" rel="stylesheet">
  </head>
  
  <body  data-target="#navbar1" data-offset="60">
    <header class="bg-primary">
    </header>
        <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-primary" id="navbar1">
        <div class="container">
            <a class="navbar-brand mr-1 mb-1 mt-0" href="./index.html">PsyLine</a>
            <div class="navbar-collapse collapse justify-content-center" id="collapsingNavbar">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" style="text-decoration: underline;" href="diagnostic.html">
                          Diagnostic
                        </a>
                       
                        
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                        Rendez-Vous
                        </a>
                    </li>
                    
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDd" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          Nos Produits
                        </a>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDd">
                            <a class="dropdown-item px-2" href="#more">Parapharmacie</a>
                            <a class="dropdown-item px-2" href="#more">Livres</a>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                        Forum
                        </a>
                    </li>
                </ul>
                <ul class="navbar-nav ml-auto">
                    
                        
                        
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#buttons">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#navs">Créer un Compte</a>
                    </li>
                    
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDd" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          More
                        </a>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDd">
                            <a class="dropdown-item px-2" href="#more">Facebook</a>
                            <a class="dropdown-item px-2" href="#more">Contactez-nous</a>

                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </nav> 
    <main>
        
        <section style="margin: 100px;align-content: center;" id="cards" class="container pb-5">
            <div class="card border-primary h-100">
                <div class="card-body d-flex flex-column align-items-start">

<div class="content delete">
	<h2>Supprimer le Résultat #<?=$score['id']?></h2>
    <?php if ($msg): ?>
    <p><?=$msg?></p>
    <?php else: ?>
	<p>Etes vous sûr de vouloir supprimer le résultat #<?=$score['id']?>?</p>
    <div class="yesno">
        <a href="deletescoreuser.php?id=<?=$score['id']?>&confirm=yes">Oui</a>
        <a href="deletescoreuser.php?id=<?=$score['id']?>&confirm=no">Non</a>
    </div>
    <?php endif; ?>
</div>

</div>
            </div>
            
            
            
        </section>
        
    </main>
        <footer id="footer" class="bg-dark text-light py-5">
          
        </footer> 
    <script src="jquery.min.js"></script>
    <script src="popper.min.js"></script>
    <script src="bootstrap.min.js"></script>
    <script src="scripts.js"></script>
    
</body>
</html>