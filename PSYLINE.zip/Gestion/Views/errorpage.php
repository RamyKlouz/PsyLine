<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>PSYLine - ERROR</title>
		<link href="./theme.css" rel="stylesheet">
        <link href="./template.css" rel="stylesheet">
	</head>
	<body data-spy="scroll" data-offset="60">
	    <header class="bg-primary">
	    	<div class="container h-100">
            <div class="row h-100">
            <div class="col-12">
                <div class="text-center m-0 vh-100 d-flex flex-column justify-content-center text-light">
                <center>
            	<h1>Ooups ERROR 404</h1>
                <a href="index.php"> Go back to login page </a>
                </center>
            </div>
            </div>
            </div>
            </div>
        </header>
	</body>
</html>