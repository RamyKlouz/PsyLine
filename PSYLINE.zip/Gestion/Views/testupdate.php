<?php
Session_start();
require_once '../Controller/User_C.php';
?>
<!DOCTYPE html>

<html lang="en">
	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>PSYLine - Incription</title>
		<link href="./theme.css" rel="stylesheet">
        <link href="./template.css" rel="stylesheet">
        <script src="Script.js"></script>
	</head>
	<body data-spy="scroll" data-offset="60">
	    <header class="bg-primary">
	    	<div class="container h-100">
            <div class="row h-100">
            <div class="col-12">
                <div class="text-center m-0 vh-100 d-flex flex-column justify-content-center text-light">
            <center>
                <?php
                    $server = "localhost";
                    $login = "root";
                    $pass = "";
                    $connexion = new PDO("mysql:host=$server;dbname=psyline",$login,$pass);

                    $pdoStat = $connexion->prepare("SELECT * from utilisateur where ID ='".$_SESSION['id']."'");
                    
                    $executeIsOk = $pdoStat->execute();
                    $admin = $pdoStat->fetchAll();



                  if(isset($_POST['update']))
                  {
                    foreach ($admin as $num) {

                //$adr = new Adresse($_POST['up_numrue'],$_POST['up_nomrue'],$_POST['up_ville']);
                        $pdoStatic = $connexion->prepare("SELECT * from adresse where ID ='".$num['Adresse']."'");
                                
                $sql="UPDATE adresse SET 
                    Num_Rue = '".$_POST["Num_Rue"]."',
                    Nom_Rue = '".$_POST["Nom_Rue"]."', 
                    Ville = '".$_POST["Ville"]."'
                    WHERE ID = '".$num["Adresse"]."'";

                $pdoStatic = $connexion->prepare($sql);
                $res = $pdoStatic->execute();

                $sqli = "UPDATE utilisateur SET 
                        Nom = '".$_POST['Nom']."', 
                        Prenom = '".$_POST['Prenom']."',
                        DateNais = '".$_POST['DateNais']."',
                        Sexe = '".$_POST['Sexe']."',
                        Telephone = '".$_POST['Telephone']."', 
                        Adresse_email = '".$_POST['Adresse_email']."',
                        Pseudo = '".$_POST['Pseudo']."',
                        Mot_de_passe = '".$_POST['Mot_de_passe']."'
                    WHERE ID = '".$num['ID']."'; ";

                $pdoStatic = $connexion->prepare($sqli);
                $res = $pdoStatic->execute();

                if($res){
                $test = true;
                
                //header('Location:../Views/index.php?testup='.$test);
                }
                else{
                    header('Location:../Views/errorpage.php');
                }
            }
            }

                ?>
	            <form action="testupdate.php" method="post">
                    
            	   <h1>Modifier profil</h1><br/>
            	   <table>
                    <?php
                    foreach ($admin as $value) {
                    ?>
            	   <tr>		        
		        		<td>
                            <h4>
                            <label>Nom :</label>
                            </h4>
                        </td>
                        <td>
                            <div class="col-lg-3 col-sm-6 mx-auto">
                                <div class="input-group ml-4 mb-1 mt-2">
                                	<input type="text" name="Nom" id="up_nom" class="form-control form-control-lg-4" onblur="testchamp('Nom','test_nom')" value="<?php echo $value['Nom'];?>">
                                    <div id="test_nom" class="invalid-feedback">
                                    is required.
                                    </div> 
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <h4>
                            <label>Prénom :</label>
                            </h4>
                        </td>
                        <td>
                            <div class="col-lg-3 col-sm-6 mx-auto">
                                <div class="input-group ml-4 mb-1 mt-2">
                                    <input type="text" name="Prenom" id="up_prenom" class="form-control form-control-lg-4" onblur="testchamp('Prenom','test_prenom')" value="<?php echo $value['Prenom'];?>">
                                    <div id="test_prenom" class="invalid-feedback">
                                    is required.
                                    </div> 
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <h4>
                            <label>Date de naissance :</label>
                            </h4>
                        </td>
                        <td>
                            <div class="col-lg-3 col-sm-6 mx-auto">
                                <div class="input-group ml-4 mb-1 mt-2">
                                	<input type="date" name="DateNais" id="up_dateNais" class="form-control form-control-lg-4" value="<?php echo $value['DateNais'];?>" >
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <h4>
                            <label>Sexe :</label>
                            </h4>
                        </td>
                        <td>
                            <div class="col-lg-3 col-sm-4 mx-4">
                                <input type="radio" name="Sexe" id="up_sexe" value="Homme" class="form-control form-control-lg" <?php if($value['Sexe'] == 'Homme') echo 'checked';?> >Homme
                            </div>
                            <div class="col-lg-3 col-sm-6 mx-4">
                                <input type="radio" name="Sexe" id="up_sexe" value="Femme" class="form-control form-control-lg" <?php if($value['Sexe'] == 'Femme') echo 'checked';?>>Femme
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <h4>
                            <label>Téléphone :</label>
                            </h4>
                        </td>
                        <td>
                            <div class="col-lg-3 col-sm-6 mx-auto">
                                <div class="input-group ml-4 mb-1 mt-2">
                                    <input type="tel" name="Telephone" id="up_tel" value="<?php echo $value['Telephone'];?>" class="form-control form-control-lg-4" maxlength="8">
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <h4>
                            Adresse :
                            </h4>
                        </td>
                        <td>
                            <table>
                            <?php
                                $pdoState = $connexion->prepare("SELECT * from adresse where ID ='".$value['Adresse']."'");
                                
                                $executeIsOke = $pdoState->execute();
                                $test = $pdoState->fetchAll();
                                
                                foreach($test as $row)
                                {
                            ?>
                            
                                <tr>
                                    <td>
                                        <label class="input-group ml-4">N°Rue :</label>
                                    </td>
                                    <td>
                                        <div class="col-lg-3 col-sm-6 mx-auto">
                                            <div class="input-group mb-1 mt-2">
                                                <input type="number" name="Num_Rue" id="up_numrue" class="form-control form-control-lg-4"  value="<?php echo $row['Num_Rue'];?>" min="1" required>
                                            </div>
                                        </div>
                                    </td>
                                </tr>                       
                                <tr>
                                    <td>
                                        <label class="input-group ml-4">Nom du Rue :</label>
                                    </td>
                                    <td>
                                        <div class="col-lg-3 col-sm-6 mx-auto">
                                            <div class="input-group mb-1 mt-2">
                                                <input type="text" name="Nom_Rue" id="up_nomrue" class="form-control form-control-lg-4" pattern="[A-Za-z]*" value="<?php echo $row['Nom_Rue'];?>" required >
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label class="input-group ml-4">Ville :</label>
                                    </td>
                                    <td>
                                        <div class="col-lg-3 col-sm-6 mx-auto">
                                            <div class="input-group mb-1 mt-2">
                                                <input type="text" name="Ville" id="up_ville" class="form-control form-control-lg-4" value="<?php echo $row['Ville'];?>" pattern="[A-Za-z]*" required >
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            
                            <?php
                                }
                            ?>
                            </table>
                        </td>
                    </tr>             
                    <tr>
                        <td>
                            <h4>
                            <label>Pseudo :</label>
                            </h4>
                        </td>
                        <td>
                            <div class="col-lg-3 col-sm-6 mx-auto">
                                <div class="input-group ml-4 mb-1 mt-2">
                                    <input type="text" name="Pseudo" id="Pseudo" value="<?php echo $value['Pseudo'];?>" class="form-control form-control-lg-4" required>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <h4>
                            <label>Email :</label>
                            </h4>
                        </td>
                        <td>
                            <div class="col-lg-3 col-sm-6 mx-auto">
                                <div class="input-group ml-4 mb-1 mt-2">
                                    <input type="email" name="Adresse_email" id="up_email_adr" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" value="<?php echo $value['Adresse_email'];?>" class="form-control form-control-lg-4" required>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <h4>
                            <label>Mot de passe :</label>
                            </h4>
                        </td>
                        <td>
                            <div class="col-lg-3 col-sm-6 mx-auto">
                                <div class="input-group ml-4 mb-1 mt-2">
                                    <input type="password" name="Mot_de_passe" id="up_pass" value="<?php echo $value['Mot_de_passe'];?>" class="form-control form-control-lg-4" required>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <h4>
                            <label>Confirmer mot de passe :</label>
                            </h4>
                        </td>
                        <td>
                            <div class0="col-lg-3 col-sm-6 mx-auto">
                                <div class="input-group ml-4 mb-1 mt-2">
                                    <input type="password" name="pass1" id="pass1" class="form-control form-control-lg-4">
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <div class0="col-lg-3 col-sm-6 mx-auto">
                                <input type="submit" class="btn btn-outline-success btn-lg rounded-right" value="Update" name="update">
                            </div>
                        </td>
			        </tr>
                    <?php

                }
                ?>
			    </table>
			</form>
		</center>
        </div>
        </div>
        </div>
        </div>
    </header>
	</body>
</html>