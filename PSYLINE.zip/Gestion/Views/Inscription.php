<?php
require_once '../Controller/User_C.php';
?>
<!DOCTYPE html>

<html lang="en">
	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>PSYLine - Incription</title>
		<link href="./theme.css" rel="stylesheet">
        <link href="./template.css" rel="stylesheet">
        <script src="Script.js"></script>
	</head>
	<body data-spy="scroll" data-offset="60">
	    <header class="bg-primary">
	    	<div class="container h-100">
            <div class="row h-100">
            <div class="col-12">
                <div class="text-center m-0 vh-100 d-flex flex-column justify-content-center text-light">
            <center>
                
	            <form onsubmit="return confirmpass();" action="<?php $User = new User_C();$User->createuser(); ?>" method="post">
                    
            	   <h1>Formulaire d'inscription</h1><br/>
            	   <table>
            	   <tr>		        
		        		<td>
                            <h4>
                            <label>Nom :</label>
                            </h4>
                        </td>
                        <td>
                            <div class="col-lg-3 col-sm-6 mx-auto">
                                <div class="input-group ml-4 mb-1 mt-2">
                                	<input type="text" name="nom" id="nom" class="form-control form-control-lg-4" maxlength="20"
                                    onblur="testchamp('nom','test_nom')" pattern="[A-Za-z]*" required>
                                    <div id="test_nom" class="invalid-feedback">
                                    is required.
                                    </div> 
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <h4>
                            <label>Prénom :</label>
                            </h4>
                        </td>
                        <td>
                            <div class="col-lg-3 col-sm-6 mx-auto">
                                <div class="input-group ml-4 mb-1 mt-2">
                                    <input type="text" name="prenom" id="prenom" class="form-control form-control-lg-4" onblur="testchamp('prenom','test_pren')" pattern="[A-Za-z]*" maxlength="20" required>
                                    <div id="test_pren" class="invalid-feedback">
                                    is required.
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <h4>
                            <label>Date de naissance :</label>
                            </h4>
                        </td>
                        <td>
                            <div class="col-lg-3 col-sm-6 mx-auto">
                                <div class="input-group ml-4 mb-1 mt-2">
                                	<input type="date" name="dateNais" id="dateNais" class="form-control form-control-lg-4" max="2002-01-01" required>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <h4>
                            <label>Sexe :</label>
                            </h4>
                        </td>
                        <td>
                            <div class="col-lg-3 col-sm-4 mx-4">
                                <input type="radio" name="sexe" id="sexe" value="Homme" class="form-control form-control-lg" checked>Homme
                            </div>
                            <div class="col-lg-3 col-sm-6 mx-4">
                                <input type="radio" name="sexe" id="sexe" value="Femme" class="form-control form-control-lg" >Femme
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <h4>
                            <label>Téléphone :</label>
                            </h4>
                        </td>
                        <td>
                            <div class="col-lg-3 col-sm-6 mx-auto">
                                <div class="input-group ml-4 mb-1 mt-2">
                                    <input type="tel" name="tel" id="tel" placeholder="12 345 678" pattern="[1-9][0-9]*" onblur="testchamp('tel','test_tel')" maxlength="8" class="form-control form-control-lg-4" required>
                                    <div id="test_tel" class="invalid-feedback">
                                    is required.
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <h4>
                            Adresse :
                            </h4>
                        </td>
                        <td>
                            <table>
                                <tr>
                                    <td>
                                        <label class="input-group ml-4">N°Rue :</label>
                                    </td>
                                    <td>
                                        <div class="col-lg-3 col-sm-6 mx-auto">
                                            <div class="input-group mb-1 mt-2">
                                                <input type="number" name="numrue" id="numrue" class="form-control form-control-lg-4" min="1" required>
                                            </div>
                                        </div>
                                    </td>
                                </tr>                       
                                <tr>
                                    <td>
                                        <label class="input-group ml-4">Nom du Rue :</label>
                                    </td>
                                    <td>
                                        <div class="col-lg-3 col-sm-6 mx-auto">
                                            <div class="input-group mb-1 mt-2">
                                                <input type="text" name="nomrue" id="nomrue" class="form-control form-control-lg-4" pattern="[A-Za-z]*" required>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label class="input-group ml-4">Ville :</label>
                                    </td>
                                    <td>
                                        <div class="col-lg-3 col-sm-6 mx-auto">
                                            <div class="input-group mb-1 mt-2">
                                                <input type="text" name="ville" id="ville" class="form-control form-control-lg-4" pattern="[A-Za-z]*" required>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>             
                    <tr>
                        <td>
                            <h4>
                            <label>Pseudo :</label>
                            </h4>
                        </td>
                        <td>
                            <div class="col-lg-3 col-sm-6 mx-auto">
                                <div class="input-group ml-4 mb-1 mt-2">
                                    <input type="text" name="pseudo" id="pseudo" class="form-control form-control-lg-4" required>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <h4>
                            <label>Email :</label>
                            </h4>
                        </td>
                        <td>
                            <div class="col-lg-3 col-sm-6 mx-auto">
                                <div class="input-group ml-4 mb-1 mt-2">
                                    <input type="email" name="email_adr" id="eamil_adr" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" class="form-control form-control-lg-4" required>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <h4>
                            <label>Mot de passe :</label>
                            </h4>
                        </td>
                        <td>
                            <div class="col-lg-3 col-sm-6 mx-auto">
                                <div class="input-group ml-4 mb-1 mt-2">
                                    <input type="password" name="pass" id="pass" class="form-control form-control-lg-4" required>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <h4>
                            <label>Confirmer mot de passe :</label>
                            </h4>
                        </td>
                        <td>
                            <div class0="col-lg-3 col-sm-6 mx-auto">
                                <div class="input-group ml-4 mb-1 mt-2">
                                    <input type="password" name="pass1" id="pass1" class="form-control form-control-lg-4" required>
                                    <div id="test_conf" class="invalid-feedback">
                                    is required.
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <div class0="col-lg-3 col-sm-6 mx-auto">
                                <input type="submit" class="btn btn-outline-success btn-lg rounded-right" value="Confirmer">
                            </div>
                        </td>
						<td>
                            <div class0="col-lg-3 col-sm-6 mx-auto">
                                <a href="./index.php" class="btn btn-outline-secondary btn-lg rounded-right">Annuler</a> <!-- retour à la page d'acceuil -->
                            </div>
                        </td>
			        </tr>
			    </table>
			</form>
		</center>
        </div>
        </div>
        </div>
        </div>
    </header>
	</body>
</html>