<?php
require_once '../Controller/User_C.php';
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PSYLine - LoginAdmin</title>
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/3.0.0/css/ionicons.css" rel="stylesheet">

    <link href="./theme.css" rel="stylesheet">
    <link href="./template.css" rel="stylesheet">
  </head>
  
  <body data-spy="scroll" data-offset="60">
    <header class="bg-primary">
        <div class="container h-100">
            <div class="row h-100">
                <div class="col-12">
                    <div class="text-center m-0 vh-100 d-flex flex-column justify-content-center text-light">
                        <center>
                          <img src="logo.png" width="100">
                        </center>
                        <form action="<?php $User = new User_C();$User->LoginAdmin(); ?>" method="post"> <!-- lien vers page php controller-->
                        <div class="row">
                            <div class="col-lg-5 col-sm-6 mx-auto">
                                <div class="input-group mb-3 mt-4">
                                  <input type="text" class="form-control form-control-lg" name="login_pseu" id="login_pseu" placeholder="your Username" required>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-5 col-sm-6 mx-auto">
                                <div class="input-group mb-3">
                                  <input type="password" class="form-control form-control-lg" name="login_passw" id="login_passw" placeholder="your password" required>
                                  <div class="input-group-append">
                                    <input type="submit" class="btn btn-outline-light btn-lg rounded-right" value="Login">
                                  </div>
                                </div>
                            </div>
                        </div>
                        <?php if(isset($_GET['test']) && $_GET['test'] == false) echo '<label><span class="text-warning "> invalid password or Username !! </span></label>'; ?>
                    </form>
                    </div>
                </div>
            </div>
        </div>
    </header> 
    <script src="//ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>