function testchamp(name,nf) { 
    var nom = window.document.getElementById(name).value.trim();
    if (nom.length <=0){
    	window.document.getElementById(name).className = "form-control is-invalid form-control-lg-4";
    	window.document.getElementById(nf).innerHTML = " le "+name+" doit être non vide ! "
    }
    else{
    	window.document.getElementById(name).className = "form-control is-valid form-control-lg-4";
    }
}

function confirmpass(){
	var pass = window.document.getElementById('pass').value;
	var passconf = window.document.getElementById('pass1').value;
	if(pass === passconf){
		return true;
	}else
	{
		window.document.getElementById('pass').className = "form-control is-invalid form-control-lg-4";
		window.document.getElementById('pass1').className = "form-control is-invalid form-control-lg-4";
    	window.document.getElementById('test_conf').innerHTML = " Confirmer votre mot de passe ! ";
		return false;
	}
}