<?php
require_once '../Controller/User_C.php';
Session_start();

?>
<!DOCTYPE html>

<html lang="en">
	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>PSYLine - Delete</title>
		<link href="./theme.css" rel="stylesheet">
        <link href="./template.css" rel="stylesheet">
	</head>
	<body data-spy="scroll" data-offset="60">
	    <header class="bg-primary">
	    	<?php if(isset($_GET['testup'])){ /*&& $_GET['testup'] == true)*/ ?>
      
<?php } ?>
	    	<div class="container h-100">
            <div class="row h-100">
            <div class="col-12">
                <div class="text-center m-0 vh-100 d-flex flex-column justify-content-center text-light">
            <center>
                
	            <!--<form action="<-?php $User = new User_C();$User->delete($_SESSION['Adresse'],$_SESSION['id']); ?>" method="post">-->
                    
            	   <h1>Liste des utilisateurs</h1><br/>
            	   <table class="table table-hover table-sm">
                            <tbody>
                                <tr>
                                    <th class="w-25">Nom</th>
                                    <th class="w-50">Prénom</th>
                                    <th class="w-25">E-mail</th>
                                    <th class="w-25"> Actions</th>
                                </tr>
                                <?php
                                 $server = "localhost";
                                 $login = "root";
                                 $pass="";
                                 $connexion = new PDO("mysql:host=$server;dbname=psyline",$login,$pass);
                                 $pdoStat = $connexion->prepare("Select * from utilisateur u join admin a on ID <> ID_Admin where display='Yes'");
                                 $executeisOk= $pdoStat->execute();
                                 $Users = $pdoStat->fetchAll();

                            	foreach($Users as $row)
                            	{
                            	?>
                            
                                <tr class="table-primary">
                                    <td><?php echo $row['Nom'];?></td>
                                    <td><?php echo $row['Prenom'];?></td>
                                    <td><?php echo $row['Adresse_email'];?></td>

                                    <td>
                                    	<form  action="../Controller/delete.php" method="post">
                                    	<input type="submit" class="btn btn-outline-success btn-lg rounded-right" value="Supprimer" name="delete">
                                    	<input type="hidden" name="id" value="<?php echo $row['ID']; ?>">
                                    	<input type="hidden" name="idr" value="<?php echo $row['Adresse']; ?>">
                                    	
                                    </form>	
                                    </td>
                                
                                </tr>

                                    
                                <?php
                            }
                        
                                ?>
                                 </tbody>
                        </table>
                        <table>
                                <h1>Archive</h1><br/>
            	   <table class="table table-hover table-sm">
                            <tbody>
                                <tr>
                                    <th class="w-25">Nom</th>
                                    <th class="w-50">Prénom</th>
                                    <th class="w-25">E-mail</th>
                                    
                                </tr>
                                <?php
                                $server = "localhost";
                                 $login = "root";
                                 $pass="";
                                 $connexion = new PDO("mysql:host=$server;dbname=psyline",$login,$pass);
                                 $pdoStat = $connexion->prepare("Select * from utilisateur u join admin a on ID <> ID_Admin where display='No'");
                                 $executeisOk= $pdoStat->execute();
                                 $Users = $pdoStat->fetchAll();

                            	foreach($Users as $row)
                            	{
                            	?>
                            
                                <tr class="table-primary">
                                    <td><?php echo $row['Nom'];?></td>
                                    <td><?php echo $row['Prenom'];?></td>
                                    <td><?php echo $row['Adresse_email'];?></td>

                                    
                                
                                </tr>
                                <?php

                                }
                                ?>
                                </table>
                           
			<!--</form>-->
		</center>
        </div>
        </div>
        </div>
        </div>
    </header>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
	</body>
</html>