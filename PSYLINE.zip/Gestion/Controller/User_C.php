<?php
require_once ('../Model/Utilisateur.php');
require_once '../Model/Adresse.php';
require_once "../Config.php";

class User_C {

	public function __construct (){

	}

	public function LoginAdmin(){
		$db = Config::getConnexion();
		if (isset($_POST['login_pseu'])&&isset($_POST['login_passw'])){
			$sql_query =  "SELECT * FROM admin,utilisateur where ID_Admin=ID and Pseudo='".$_POST['login_pseu']."' and Mot_de_passe = '".$_POST['login_passw']."'";
			$query = $db->prepare($sql_query);
            $query->execute();
            $res = $query->fetchall();
            if(count($res) <=0){
            	$test = false;
            	header('Location:../Views/LoginAdmin.php?test='.$test);
            }else
            {
            	
            	session_start();
            	foreach ($res as $row ) {
            		$_SESSION['id']=$row['ID'];
            		$_SESSION['nom']=$row['Nom'];
            		$_SESSION['Prenom']=$row['Prenom'];
            		$_SESSION['DateNais']=$row['DateNais'];
            		$_SESSION['Sexe']=$row['Sexe'];
            		$_SESSION['Telephone']=$row['Telephone'];
            		$_SESSION['Adresse_mail']=$row['Adresse_email'];
            		$_SESSION['Pseudo']=$row['Pseudo'];
            		$_SESSION['Mot_de_passe']=$row['Mot_de_passe'];
            		$_SESSION['Adresse']=$row['Adresse'];
            		$a = "SELECT * FROM adresse where ID=".$row['Adresse'];  
            		$query = $db->prepare($a);
		            $query->execute();
		            $res1 = $query->fetchall();
		           foreach ($res1 as $row1 ){
		                    $_SESSION['Num_Rue']=$row1['Num_Rue'];
		            		$_SESSION['Nom_Rue']=$row1['Nom_Rue'];
		            		$_SESSION['Ville']=$row1['Ville'];

		           }
		           $a1 = "SELECT * FROM utilisateur where ID!=".$row['ID_Admin'];  
            		$query = $db->prepare($a1);
		            $query->execute();
		            $res2 = $query->fetchall();
		           $_SESSION['listeUsers']=$res2;

            	}
            	
            	header('Location:../Views/AfficherUtilisateur.php');
            }
            $db = null;
            unset($db);
		}
	}

	

	public function createuser()
	{
		$db = Config::getConnexion();
		if (isset($_POST['numrue'])&&isset($_POST['nomrue'])&&isset($_POST['ville'])&&isset($_POST['nom'])&&isset($_POST['prenom'])&&isset($_POST['dateNais'])&&isset($_POST['sexe'])&&isset($_POST['tel'])&&isset($_POST['email_adr'])&&isset($_POST['pseudo'])&&isset($_POST['pass'])){
        	
        	$adr = new Adresse($_POST['numrue'],$_POST['nomrue'],$_POST['ville']);

            $sql="INSERT INTO adresse (Num_Rue,Nom_Rue,Ville) 
                VALUES (".$_POST['numrue'].",'".$_POST['nomrue']."','".$_POST['ville']."')";

            $id_adr = $adr->create($db,$sql);

            $User = new  Utilisateur($_POST['nom'],$_POST['prenom'],$_POST['dateNais'],$_POST['sexe'],$_POST['tel'],intval($id_adr),$_POST['email_adr'],$_POST['pseudo'],$_POST['pass']) ;

            $sql = "INSERT INTO utilisateur(Nom,Prenom,DateNais,Sexe,Telephone,Adresse_email,Pseudo,Mot_de_passe,Adresse,display) 
                    VALUES('".$_POST['nom']."','".$_POST['prenom']."','".$_POST['dateNais']."','".$_POST['sexe']."','".$_POST['tel']."','".$_POST['email_adr']."','".$_POST['pseudo']."','".$_POST['pass']."',".$id_adr.",'Yes')";

            $res = $User->create($db,$sql);
            $db = null;
            unset($db);
            if($res){
            	$test = true;
                header('Location:../Views/index.php?testadd='.$test);
            }
            else{
                header('Location:../Views/errorpage.php');
            }
       	}
	}
}
?>