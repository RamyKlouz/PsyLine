<?php
Session_start();
require_once "../Config.php";
require_once ('../Model/Utilisateur.php');
require_once '../Model/Adresse.php';
if(isset($_POST['delete']))
{
								 $server = "localhost";
                                 $login = "root";
                                 $pass="";
                                 $id=$_POST['id'];
                                 $connexion = new PDO("mysql:host=localhost;dbname=psyline",$login,$pass);
                                 $pdoStat = $connexion->prepare("update utilisateur set display='No' where id='".$id."' ");
                                 $executeisOk= $pdoStat->execute();
                                 $test = true;
                				 header('Location:../Views/AfficherUtilisateur.php?testup='.$test);
                                 }
if(isset($_POST['login']))
{
			
 $server = "localhost";
 $login = "root";
 $pass = "";
 $connexion = new PDO("mysql:host=$server;dbname=psyline",$login,$pass);

 $pdoStat = $connexion->prepare("SELECT * from utilisateur where display='Yes'");
 
 $executeIsOk = $pdoStat->execute();
 $admin = $pdoStat->fetchAll();
    
   $bool = false;
     foreach($admin as $value)
     {
         if ($_POST['login_passw'] == $value['Mot_de_passe'] & (strtoupper($_POST['login_pseu']) == strtoupper($value['Pseudo'])))
         {
             $_SESSION['id']=$value['ID'];
             $bool = true;
             echo $bool;
             header("location:../../Front/Views/index.html");
         }
     }
     if($bool)
     {
       echo"<script> 
             document.location.href='../Views/testupdate.php'; </script>";
     }
     else
     {
       echo '<script>
       document.location.href="../Views/errorpage.php"
       </script>';
     }
}

?>