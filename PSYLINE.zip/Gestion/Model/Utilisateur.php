<?php
require_once "../Config.php";

class Utilisateur {
        private int $id ;
	private string $Nom ;
	private string $Prenom ;
	private string $DateNais ;
	private string $Sexe ;
	private string $Telephone ;
	private int $id_adresse ;
	private string $Adresse_mail;
	private string $Pseudo ;
	private string $Mdp ;

	public function __construct (string $nom ,string $prenom ,string $dateNais ,string $Sexe ,string $Tel ,int $id_adresse ,string $Mail ,string $Pseudo ,string $Mdp )
	{
        $this->Nom = $nom ;
        $this->Prenom = $prenom ;
        $this->DateNais = $dateNais ;
        $this->Sexe = $Sexe ;
        $this->Telephone = $Tel ;
        $this->id_adresse = $id_adresse ;
        $this->Adresse_mail = $Mail ;
        $this->Pseudo = $Pseudo ;
        $this->Mdp = $Mdp ;
	}
        
        
        public function getuser()
        {
        
         try{
                $sql =  "SELECT * FROM utilisateur";
                $db = Config::getConnexion();
                $liste = $db->query($sql);
             }
                catch (Exception $e)
                {
                        die('Erreur: '.$e->getMessage());
                }
        }
        

        public function create(PDO $db,string $sql) : bool{
                try{
                $query = $db->prepare($sql);
                $res = $query->execute();
                return true;
                }
                catch (Exception $e){
                        die('Erreur: '.$e->getMessage());
                        return false;
                } 
        }


	public function afficherUtilisateur ()
	{
        echo "<table border='1' align='center' >";
        echo "<tr>";
        echo " <td> Nom : </td> <td> $this->Nom </td>" ;
        echo "</tr> <tr>";
        echo " <td> Prénom : </td> <td> $this->Prenom </td> " ;
        echo "</tr> <tr>";
        echo " <td> DateNais : </td> <td> $this->DateNais </td> " ;
        echo " </tr> <tr>";
        echo " <td> Sexe : </td> <td> $this->Sexe </td> " ;
        echo " </tr> <tr>";
        echo " <td> Téléphone : </td> <td> $this->Telephone </td> " ;
        echo "</tr> <tr>";
        echo "<td> Profession : </td> <td> $this->Profession </td> " ;
        echo "</tr> <tr>";
        echo " <td> Adresse e-mail : </td> <td> $this->Adresse_mail </td> " ;
        echo "</tr> <tr>";
        echo "<td> Pseudo : </td> <td> $this->Pseudo </td> " ;
        echo " </tr> <tr> ";
        echo "<td> Mdp : </td> <td> $this->Mdp </td> " ;
        echo " </tr>";
        echo " </table>"; 
	}

        function getId(): int{
                return $this->id;
        }
        function getNom(): string{
                return $this->Nom;
        }
        function getPrenom(): string{
                return $this->Prenom;
        }
        function getDateNais(): string{
                return $this->DateNais;
        }
        function getSexe(): string{
                return $this->Sexe;
        }
        function getTelephone(): string{
                return $this->Telephone;
        }
        function getid_adresse(): string{
                return $this->id_adresse;
        }
        function getPseudo(): string{
                return $this->Pseudo;
        }
        function getAdresse_mail(): string{
                return $this->Adresse_mail;
        }
        function getMdp(): string{
                return $this->Mdp;
        }

        function setNom(string $nom): void{
                $this->Nom=$nom;
        }
        function setPrenom(string $prenom): void{
                $this->Prenom=$prenom;
        }
        function setDateNais(string $DateNais): void{
                $this->DateNais=$DateNais;
        }
        function setSexe(string $Sexe): void{
                $this->Sexe=$Sexe;
        }
        function setTelephone(string $Telephone): void{
                $this->Telephone=$Telephone;
        }
        function setid_adresse(string $id_adresse): void{
                $this->id_adresse=$id_adresse;
        }
        function setPseudo(string $Pseudo): void{
                $this->Pseudo=$pseudo;
        }
        function setAdresse_mail(string $Mail): void{
                $this->Adresse_mail=$Mail;
        }
        function setMdp(string $Mdp): void{
                $this->Mdp=$Mdp;
        }
}
?>