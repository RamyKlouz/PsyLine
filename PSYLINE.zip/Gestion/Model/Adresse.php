<?php
require_once "../Config.php";

class Adresse {
	private int $id_adresse ;
	private int $NumRue ;
	private string $NomRue;
	private string $Ville;

	public function __construct (int $NumRue , string $NomRue , string $Ville )
	{
		$this->NumRue=$NumRue;
		$this->NomRue=$NomRue;
		$this->Ville=$Ville;
	}

	public function create (PDO $db,string $sql) : int{
        try{
            $query = $db->prepare($sql);
            $res = $query->execute();
            $sql_query =  "SELECT  MAX(ID) AS ID FROM adresse";
            $query = $db->prepare($sql_query);
            $query->execute();
            $res_adr = $query->fetchall();
            foreach ($res_adr as $row) {
            	$id_adr = $row['ID'];
            }
            return $id_adr;
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        } 
	}

	function getid_adresse(): int{
        return $this->id_adresse;
    }
	function getNumRue(): int{
        return $this->NumRue;
    }
    function getNomRue(): string{
        return $this->NomRue;
    }
    function getVille (): string{
        return $this->Ville;
    }
    function setNumRue(string $NumRue): void{
        $this->NumRue=$NumRue;
    }
    function setNomRue(string $NomRue): void{
        $this->NomRue=$NomRue;
    }
    function setVille(string $Ville): void{
        $this->Ville=$Ville;
	}
	}
?>