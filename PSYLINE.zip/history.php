<?php
include './Front/functions.php';

$pdo = pdo_connect_mysql();
$stmt = $pdo->prepare('SELECT * FROM scores  WHERE name = "sam" ORDER BY created ');
$stmt->execute();

// Fetch the records so we can display them in our template.
$scores = $stmt->fetchAll(PDO::FETCH_ASSOC);

$stmt2 = $pdo->prepare('SELECT * FROM scores ');
$stmt2->execute();
$allscores = $stmt2->fetchAll(PDO::FETCH_ASSOC);
$num_scoresuser = $pdo->query('SELECT COUNT(*) FROM scores  WHERE name = "sam" ')->fetchColumn();


?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fresca Bootstrap 4 Theme Full Screen</title>
    <meta name="generator" content="Themestr.app">
    <link href="./back/styletables.css" rel="stylesheet" type="text/css">
    <link rel="icon" href="http://themes.guide/favicon.ico" type="image/x-icon" />
    <link rel="shortcut icon" href="http://themes.guide/favicon.ico" type="image/x-icon" />
    <meta property="og:image" name="twitter:image" content="http://bootstrap.themes.guide/assets/ss_fresca.png">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/3.0.0/css/ionicons.css" rel="stylesheet">
    <link href="./theme.css" rel="stylesheet">
    <link href="./template.css" rel="stylesheet">
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
// Load google charts
google.charts.load('current', {'packages':['corechart']});
google.charts.setOnLoadCallback(drawChart);

// Draw the chart and set the chart values
function drawChart() {
  var data = google.visualization.arrayToDataTable([
<?php $a=0;$b=0;$c=0;$d=0; ?>
<?php foreach ($allscores as $score): ?>
<?php if ($score['score']>=8) $a++;
else if ($score['score']<3) $d++;
else if ($score['score']>=3&&$score['score']<5) $c++;
else $b++?>
<?php endforeach; ?>

  ['Task', 'Hours per Day'],
  ['8.00-10.00', <?php echo $a?>],
  ['1.00-2.99', <?php echo $d?>],
  ['3.00-4.99', <?php echo $c?>],
  ['5.00-7.99', <?php echo $b?>],

]);

  // Optional; add a title and set the width and height of the chart
  var options = {'title':'Résultat du questionnaire globaux', 'width':700, 'height':600};

  // Display the chart inside the <div> element with id="piechart"
  var chart = new google.visualization.PieChart(document.getElementById('piechart'));
  chart.draw(data, options);
}
</script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
          <?php $o=$num_scoresuser ; $i=1;?>
        var data = google.visualization.arrayToDataTable([
          ['Essai', 'Sam'],
          <?php foreach ($scores as $score): ?>
          ['Essai n°<?=$i?>',  <?=$score['score']?>] <?php $i++;if ($o>1) {echo",";$o--;}?>
          <?php endforeach; ?>
          
        ]);

        var options = {
          title: 'Graph de vos essais',
          curveType: 'function',
          legend: { position: 'bottom' }
        };

        var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));

        chart.draw(data, options);
      }
    </script>
  </head>
  
  <body  data-target="#navbar1" data-offset="60">
    <header class="bg-primary">
    </header>
        <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-primary" id="navbar1">
        <div class="container">
            <a class="navbar-brand mr-1 mb-1 mt-0" href="./index.html">PsyLine</a>
            <div class="navbar-collapse collapse justify-content-center" id="collapsingNavbar">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" style="text-decoration: underline;" href="diagnostic.html">
                          Diagnostic
                        </a>
                       
                        
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                        Rendez-Vous
                        </a>
                    </li>
                    
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDd" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          Nos Produits
                        </a>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDd">
                            <a class="dropdown-item px-2" href="#more">Parapharmacie</a>
                            <a class="dropdown-item px-2" href="#more">Livres</a>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                        Forum
                        </a>
                    </li>
                </ul>
                <ul class="navbar-nav ml-auto">
                    
                        
                        
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#buttons">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#navs">Créer un Compte</a>
                    </li>
                    
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDd" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          More
                        </a>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDd">
                            <a class="dropdown-item px-2" href="#more">Facebook</a>
                            <a class="dropdown-item px-2" href="#more">Contactez-nous</a>

                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </nav> 
    <main>
    
        <section style="margin: 100px;align-content: center;" id="cards" class="container pb-5">
            <div class="card border-primary h-100">
                <div class="card-body d-flex flex-column align-items-start">
                <h4 class="card-title text-primary">Merci d'avoir participé au questionnaire!</h4>
                <p style="margin-bottom:20px;" class="card-text">Voici la liste de vos résultats précédants:</p>
                <div class="content read">
                <table>
                <thead>
                <tr>
                <td>Nom</td>
                <td>Votre Score</td>
                <td>Créé le</td>
                <td></td>
                </tr>
                </thead>
                <tbody>
                <?php $t=0; ?>
                <?php foreach ($scores as $score): ?>
                <tr>
                <td><?=$score['name']?></td>
                <td><?=$score['score']?></td>
                <?php $t=$t+$score['score']; ?>
                <td><?=$score['created']?></td>
                <td class="actions">
                </a>
                <a href="deletescoreuser.php?id=<?=$score['id']?>" title="Supprimer" class="btn btn-danger btn-icon-split">
                                        <span class="icon text-white-50">
                                            <i class="fas fa-trash"></i>
                                        </span>
                                        <span class="text">Supprimer</span>
                </a>
                </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table></div>
                <h3 style='margin: auto;padding-top:20px'>Moyenne de tout vos essais personnels : <span style="color:grey;"><?php echo round($t/$num_scoresuser,2); ?> </span></h3>
                </div>
                <div id="curve_chart" style="margin:auto;width: 1000px; height: 500px"></div>
                <h3 style='margin: auto;padding-top:20px'>Résultats globaux des patients sur notre site :</h3>
                <div id="piechart" style="margin:auto;"></div>
                <a href="diagnostic.php" style='margin: auto; padding: 20px; margin-bottom:50px' class="btn btn-secondary">Faire un nouvel Essai</a>
            </div>
            
            
            
        </section>
        
    </main>
        <footer id="footer" class="bg-dark text-light py-5">
        </footer> 
    <script src="jquery.min.js"></script>
    <script src="popper.min.js"></script>
    <script src="bootstrap.min.js"></script>
    <script src="scripts.js"></script>
    
</body>
</html>