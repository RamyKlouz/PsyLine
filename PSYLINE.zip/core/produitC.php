<?PHP
include "../../config.php";

class produitC {
function afficherproduit ($produit){
		echo "reference: ".$produit->getreference()."<br>";
		echo "nom: ".$produit->getnom()."<br>";
		echo "quantite: ".$produit->getquantite()."<br>";
		echo "prix: ".$produit->getprix()."<br>";
	}
	/*function calculerSalaire($produit){
		echo $employe->getNbHeures() * $employe->getTarifHoraire();
	}
	*/
	function ajouterproduit ($produit){
		$sql="insert into produit (nom,quantite,prix,image) values (:nom,:quantite,:prix,:image)";
		$db = config::getConnexion();
		try{
        $req=$db->prepare($sql);
		
        $nom=$produit->getnom();
        $quantite=$produit->getquantite();
        $prix=$produit->getprix();
        $image=$produit->getimage();
		$req->bindValue(':nom',$nom);
		$req->bindValue(':quantite',$quantite);
        $req->bindValue(':prix',$prix);
        $req->bindValue(':image',$image);
		
            $req->execute();
           
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
		
	}
	
	function afficherproduits(){
		//$sql="SElECT * From prix e inner join formationphp.prix a on e.reference= a.reference";
		$sql="SElECT * From produit";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}
	function supprimerproduit($reference){
		$sql="DELETE FROM produit where reference= :reference";
		$db = config::getConnexion();
        $req=$db->prepare($sql);
		$req->bindValue(':reference',$reference);
		try{
            $req->execute();
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function modifierproduit($produit,$reference){
		$sql="UPDATE produit SET nom=:nom,quantite=:quantite,prix=:prix,image=:image WHERE reference=$reference";
		
		$db = config::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
try{		
        $req=$db->prepare($sql);

        $nom=$produit->getnom();
        $quantite=$produit->getquantite();
        $prix=$produit->getprix();
		$image=$produit->getimage();
		//$req->bindValue(':reference',2);
		$req->bindValue(':nom',$nom);
		$req->bindValue(':quantite', $quantite);
        $req->bindValue(':prix',$prix);
        $req->bindValue(':image',$image);
		
		
            $s=$req->execute();
			
           // header('Location: index.php');
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
        }
		
	}
	function recupererproduit($reference){
		$sql="SELECT * from produit where reference=$reference";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	
	function rechercherListeproduits($reference){
		$sql="SELECT * from produit where reference=$reference";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
}

?>
