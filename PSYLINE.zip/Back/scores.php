<?php
include 'functions.php';
// Connect to MySQL database
$pdo = pdo_connect_mysql();
// Get the page via GET request (URL param: page), if non exists default the page to 1
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
// Number of records to show on each page
$records_per_page = 5;
// Prepare the SQL statement and get records from our contacts table, LIMIT will determine the page
$stmt = $pdo->prepare('SELECT * FROM scores ORDER BY id LIMIT :current_page, :record_per_page');
$stmt->bindValue(':current_page', ($page-1)*$records_per_page, PDO::PARAM_INT);
$stmt->bindValue(':record_per_page', $records_per_page, PDO::PARAM_INT);
$stmt->execute();
// Fetch the records so we can display them in our template.
$scores = $stmt->fetchAll(PDO::FETCH_ASSOC);
// Get the total number of contacts, this is so we can determine whether there should be a next and previous button
$num_scores = $pdo->query('SELECT COUNT(*) FROM scores')->fetchColumn();
?>

<?=page_header('Questionnaire - Résultats')?>

<div class="content read">
    <h2>Liste des Résultats</h2>
    <p class="mb-4">Ce tableau contient la liste des résultats du questionnaire reçues par tout les participants.
                        Vous avez la possibilité de supprimer un ou tout les scores.</p>
	<table>
        <thead>
            <tr>
                <td>#</td>
                <td>Name</td>
                <td>Score</td>
                <td>Created</td>
                <td></td>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($scores as $score): ?>
            <tr>
                <td><?=$score['id']?></td>
                <td><?=$score['name']?></td>
                <td><?=$score['score']?></td>
                <td><?=$score['created']?></td>
                <td class="actions">
                <a href="updatescore.php?id=<?=$score['id']?>" title="Modifier" class="btn btn-info btn-icon-split">
                                        <span class="icon text-white-50">
                                            <i class="fas fa-info-circle"></i>
                                        </span>
                                        <span class="text">Modifier</span>
                </a>
                <a href="deletescore.php?id=<?=$score['id']?>" title="Supprimer" class="btn btn-danger btn-icon-split">
                                        <span class="icon text-white-50">
                                            <i class="fas fa-trash"></i>
                                        </span>
                                        <span class="text">Supprimer</span>
                </a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
	<div class="pagination">
		<?php if ($page > 1): ?>
		<a href="scores.php?page=<?=$page-1?>"><i class="fas fa-angle-double-left fa-sm"></i></a>
		<?php endif; ?>
		<?php if ($page*$records_per_page < $num_scores): ?>
		<a href="scores.php?page=<?=$page+1?>"><i class="fas fa-angle-double-right fa-sm"></i></a>
		<?php endif; ?>
	</div>
</div>

<?=page_footer()?>