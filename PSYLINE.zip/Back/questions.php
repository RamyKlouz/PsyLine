<?php
include 'functions.php';

// Connect to MySQL database
$pdo = pdo_connect_mysql();
$stmt = $pdo->prepare('SELECT * FROM questions ORDER BY id');
$stmt->execute();
// Fetch the records so we can display them in our template.
$questions = $stmt->fetchAll(PDO::FETCH_ASSOC);
// Get the total number of contacts, this is so we can determine whether there should be a next and previous button
$num_questions = $pdo->query('SELECT COUNT(*) FROM questions')->fetchColumn();
?>

<?=page_header('Questionnaire')?>


        <div class="container-fluid">   
                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Liste des Questions</h1>
                    <p class="mb-4">Ce tableau contient la liste des questions qui seront posées dans le questionnaire.
                        Vous avez la possibilité d'ajouter, modifier ou de supprimer toutes les questions.</p>
                        
                                    <a href="createquestion.php" class="btn btn-success btn-icon-split">
                                        <span class="icon text-white-50">
                                            <i class="fas fa-check"></i>
                                        </span>
                                        <span class="text">Ajouter une question</span>
                                    </a>
                                    <div class="my-2"></div>
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Liste des Questions à poser </h6>
                        </div>
                        <div class="card-body">
                        <div class="content read">

                            <table>
                                <thead>
                                <tr>
                                    <td>#</td>
                                    <td  width="400">Question</td>
                                    <td width="100">Réponse 1</td>
                                    <td width="100">Réponse 2</td>
                                    <td width="100">Réponse 3</td>
                                    <td width="100">Réponse 4</td>
                                    <td width ="150">Date</td>
                                    <td></td>
                                </tr>
                                </thead>
                                <tbody>
                                <?php foreach ($questions as $question): ?>
                                <tr>
                                    <td><?=$question['id']?></td>
                                    <td><?=$question['question']?></td>
                                    <td><?=$question['a1']?></td>
                                    <td><?=$question['a2']?></td>
                                    <td><?=$question['a3']?></td>
                                    <td><?=$question['a4']?></td>
                                    <td><?=$question['created']?></td>
                                    <td class="actions">
                                            <a href="updatequestion.php?id=<?=$question['id']?>" title="Modifier" class="btn btn-info btn-circle"><i class="fas fa-info-circle"></i></a>
                                            <a href="deletequestion.php?id=<?=$question['id']?>" title="Supprimer" class="btn btn-danger btn-circle"><i class="fas fa-trash"></i></a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>

                        </div>
                        </div>
            
<?=page_footer()?>