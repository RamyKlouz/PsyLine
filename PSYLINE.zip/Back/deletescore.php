<?php
include 'functions.php';
$pdo = pdo_connect_mysql();
$msg = '';
// Check that the contact ID exists
if (isset($_GET['id'])) {
    // Select the record that is going to be deleted
    $stmt = $pdo->prepare('SELECT * FROM scores WHERE id = ?');
    $stmt->execute([$_GET['id']]);
    $score = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$score) {
        exit('Contact doesn\'t exist with that ID!');
    }
    // Make sure the user confirms before deletion
    if (isset($_GET['confirm'])) {
        if ($_GET['confirm'] == 'yes') {
            // User clicked the "Yes" button, delete record
            $stmt = $pdo->prepare('DELETE FROM scores WHERE id = ?');
            $stmt->execute([$_GET['id']]);
            $msg = 'Vous avez supprimé le résultat!';
            header( "refresh:2;url=scores.php" );
        } else {
            // User clicked the "No" button, redirect them back to the read page
            header('Location: scores.php');
            exit;
        }
    }
} else {
    exit('No ID specified!');
}
?>

<?=page_header('Supprimer un Résultat')?>

<div class="content delete">
	<h2>Supprimer le Résultat #<?=$score['id']?></h2>
    <?php if ($msg): ?>
    <p><?=$msg?></p>
    <?php else: ?>
	<p>Etes vous sûr de vouloir supprimer le résultat #<?=$score['id']?>?</p>
    <div class="yesno">
        <a href="deletescore.php?id=<?=$score['id']?>&confirm=yes">Oui</a>
        <a href="deletescore.php?id=<?=$score['id']?>&confirm=no">Non</a>
    </div>
    <?php endif; ?>
</div>

<?=page_footer()?>