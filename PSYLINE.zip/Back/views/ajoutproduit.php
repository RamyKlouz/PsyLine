<?PHP
include "../../entities/produit.php";
include "../../core/produitC.php";


$target_dir = "image/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
  $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
  if($check !== false) {
    echo "File is an image - " . $check["mime"] . ".";
    $uploadOk = 1;
  } else {
    echo "File is not an image.";
    $uploadOk = 0;
  }
}



if (isset($_POST['nom']) and isset($_POST['quantite']) and isset($_POST['prix'])){
$produit1=new produit($_POST['nom'],$_POST['quantite'],$_POST['prix'],$target_file);
?>
<script>
    console.log(<?php echo  $_POST["image"] ;?> );
</script>
<?php
$produit1C=new produitC();
$produit1C->ajouterproduit($produit1);
header('Location: afficherproduit.php');
	
}else{
	echo "vérifier les champs";
}
//*/

?>
