<?php
include 'functions.php';
$pdo = pdo_connect_mysql();
$msg = '';
// Check if the contact id exists, for example update.php?id=1 will get the contact with the id of 1
if (isset($_GET['id'])) {
    if (!empty($_POST)) {
        // This part is similar to the create.php, but instead we update a record and not insert
        $id = isset($_POST['id']) ? $_POST['id'] : NULL;
        $name = isset($_POST['name']) ? $_POST['name'] : '';
        $score = isset($_POST['score']) ? $_POST['score'] : '';
        $created = isset($_POST['created']) ? $_POST['created'] : date('Y-m-d H:i:s');
        // Update the record
        $stmt = $pdo->prepare('UPDATE scores SET id = ?, name = ?, score = ?, created = ? WHERE id = ?');
        $stmt->execute([$id, $name, $score, $created, $_GET['id']]);
        $msg = 'Mis à jour avec succès!';
    }
    // Get the contact from the contacts table
    $stmt = $pdo->prepare('SELECT * FROM scores WHERE id = ?');
    $stmt->execute([$_GET['id']]);
    $score = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$score) {
        
        echo "<script>window.location = 'scores.php'</script>";
    }
} else {
    exit('No ID specified!');
    
}
?>

<?=page_header('Mise à jour du résultat')?>

<div class="content update">
    <h2>Mettre à jour le Résultat #<?=$score['id']?> <a style="margin-left: 435px;" href="scores.php" class="btn btn-success btn-icon-split">
                                        <span class="icon text-white-50">
                                            <i class="fas fa-check"></i>
                                        </span>
                                        <span class="text">Retour</span>
                                    </a></h2>

    <form action="updatescore.php?id=<?=$score['id']?>" method="post">
        <label for="id">ID</label>
        <label for="name">Nom</label>
        <input type="text" name="id" value="<?=$score['id']?>" id="id" oninvalid="this.setCustomValidity('Veuillez remplir l\'ID')" oninput="setCustomValidity('')" required>
        <input type="text" name="name" placeholder="<?=$score['name']?>" value="<?=$score['name']?>" id="name" oninvalid="this.setCustomValidity('Veuillez remplir la question')" oninput="setCustomValidity('')" required>

        <label for="score">Score</label>
        <label for="created">Créée</label>
        <input type="text" name="score" placeholder="<?=$score['score']?>" value="<?=$score['score']?>" oninvalid="this.setCustomValidity('Veuillez remplir la réponse')" id="a4" oninput="setCustomValidity('')" required>
        <input type="datetime-local" name="created" value="<?=date('Y-m-d\TH:i', strtotime($score['created']))?>" id="created">
        <input type="submit" value="Modifier">
    </form>
    <?php if ($msg): ?>
    <p><?=$msg?></p>
    <?php endif; ?>
</div>

<?=page_footer()?>