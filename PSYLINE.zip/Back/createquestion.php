<?php
include 'functions.php';
$pdo = pdo_connect_mysql();
$msg = '';
// Check if POST data is not empty
if (!empty($_POST)) {
    // Post data not empty insert a new record
    // Set-up the variables that are going to be inserted, we must check if the POST variables exist if not we can default them to blank
    $id = isset($_POST['id']) && !empty($_POST['id']) && $_POST['id'] != 'auto' ? $_POST['id'] : NULL;
    // Check if POST variable "name" exists, if not default the value to blank, basically the same for all variables
    $question = isset($_POST['question']) ? $_POST['question'] : '';
    $a1 = isset($_POST['a1']) ? $_POST['a1'] : '';
    $a2 = isset($_POST['a2']) ? $_POST['a2'] : '';
    $a3 = isset($_POST['a3']) ? $_POST['a3'] : '';
    $a4 = isset($_POST['a4']) ? $_POST['a4'] : '';
    $created = isset($_POST['created']) ? $_POST['created'] : date('Y-m-d H:i:s');
    // Insert new record into the contacts table
    $stmt = $pdo->prepare('INSERT INTO questions VALUES (?, ?, ?, ?, ?, ?, ?)');
    $stmt->execute([$id, $question, $a1, $a2, $a3, $a4, $created]);
    // Output message
    $msg = 'Created Successfully!';
}
?>
<?=page_header('Create')?>

<div class="content update">
    <h2>Ajouter une Question</h2>
    <p class="mb-4">Veuillez ajouter une question avec 4 réponses possibles, dans l'ordre de gravité (la première réponse étant la plus grave, et la dernière la moins).
    </p>
    <form action="createquestion.php" method="post">
        
        <label for="question">Question</label>
        <label for="a1">Réponse 1</label>
        <input type="text" name="question" placeholder="Question ?" id="question" oninvalid="this.setCustomValidity('Veuillez remplir la question')" oninput="setCustomValidity('')" required>
        <input type="text" name="a1" placeholder="Réponse 1" id="a1" oninvalid="this.setCustomValidity('Veuillez remplir la réponse')" oninput="setCustomValidity('')" required>
        <label for="a2">Réponse 2</label>
        <label for="a3">Réponse 3</label>
        <input type="text" name="a2" placeholder="Réponse 2" id="a2" oninvalid="this.setCustomValidity('Veuillez remplir la réponse')" oninput="setCustomValidity('')" required>
        <input type="text" name="a3" placeholder="Réponse 3" id="a3" oninvalid="this.setCustomValidity('Veuillez remplir la réponse')" oninput="setCustomValidity('')" required>
        <label for="a4">Réponse 4</label>
        <label for="created">Created</label>
        <input type="text" name="a4" placeholder="Réponse 4" id="a4" oninvalid="this.setCustomValidity('Veuillez remplir la réponse')" oninput="setCustomValidity('')" required>
        <input type="datetime-local" name="created" value="<?=date('Y-m-d\TH:i')?>" id="created">
        <input type="submit" value="Créer">
    </form>
    <?php if ($msg): ?>
    <p><?=$msg?></p>
    <?php endif; ?>
</div>
<?=page_footer()?>